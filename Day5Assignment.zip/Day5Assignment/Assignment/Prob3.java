/*
 * Create an Interface having two methods division and modules. Create a
class, which overrides these methods.
 */
package Assignment;

/**
 *
 * @author Admin
 */
public class Prob3 {
    public static void main(String[] args)
    {
    Student s=new Student("Tom");
    s.division(5);
    s.modules(2);
    s.display();
    }
}
