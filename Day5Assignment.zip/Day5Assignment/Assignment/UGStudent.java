/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Admin
 */
public class UGStudent implements StudentInterface{
 
     String name;
     char grade;
        float attendance;
    public UGStudent(String name,char grade,float attendance)
    {
        this.name=name;
        System.out.println("Name: "+this.name);
    }
public void displayGrade(char grade)
{
    System.out.println("Grade: "+grade);
}
    public void displayattendance(float attendance)
{
    System.out.println("Attendance percent: "+attendance);
}
}
