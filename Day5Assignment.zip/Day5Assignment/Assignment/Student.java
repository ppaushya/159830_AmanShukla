/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Admin
 */
public class Student implements Course{
    
    String name;
    int div;
    int mod;

    public Student(String name)
    {
        this.name=name;
    }
    
    public void division(int a)
    {
        div=a;
    }
    public void modules(int a)
    {
        mod=a;
    }
    public void display()
    {
        System.out.println("Name: "+name+" Division: "+div+" Modules: "+mod);
        
    }
}
