package com.capgemini;

import javax.xml.ws.Endpoint;

public class CalculatorPublisher {

	public static void main(String[] args) {

		Endpoint.publish("http://localhost:7709/ws/calculator", new CalculatorImpl());
		// add ?wsdl in the url for execution in browser

	}

}
