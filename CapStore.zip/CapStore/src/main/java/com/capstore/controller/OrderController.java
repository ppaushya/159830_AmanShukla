package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.Order;
import com.capstore.service.IOrderService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/orders")
public class OrderController {

	@Autowired
	private IOrderService orderService;

	@PostMapping("/order")
	public ResponseEntity<List<Order>> displayCart() {
		List<Order> order = orderService.displayCart();

		if (order == null)
			return new ResponseEntity("Cart is Empty!! Shop more", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Order>>(order, HttpStatus.OK);
	}
	
	@PutMapping("/delete/quantity")
	public ResponseEntity<List<Order>> 
}
