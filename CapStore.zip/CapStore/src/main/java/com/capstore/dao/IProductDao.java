package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.model.Product;

public interface IProductDao extends JpaRepository<Product, Integer>{

}
