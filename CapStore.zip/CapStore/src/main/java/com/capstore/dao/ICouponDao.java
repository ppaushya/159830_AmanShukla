package com.capstore.dao;

public interface ICouponDao{

}
