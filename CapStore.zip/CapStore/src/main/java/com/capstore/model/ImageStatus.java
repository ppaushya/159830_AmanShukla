package com.capstore.model;

public enum ImageStatus {

	MAIN, SLIDER
}
