package com.capstore.model;

public enum ReturnStatus {

	ACCEPTED, COLLECTED, PROCESSED
}
