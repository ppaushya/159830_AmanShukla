package com.capstore.model;

public enum UserTypes {

	CUSTOMER, ADMIN, MERCHANT;

}