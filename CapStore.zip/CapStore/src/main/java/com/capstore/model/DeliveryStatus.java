package com.capstore.model;

public enum DeliveryStatus {

	INITIATED, DISPATCHED, SHIPPED, DELIVERED
	
}