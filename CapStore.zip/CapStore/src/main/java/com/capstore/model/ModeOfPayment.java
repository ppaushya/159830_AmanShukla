package com.capstore.model;

public enum ModeOfPayment {

	CREDITCARD, DEBITCARD, NETBANKING;
 
}