package com.capstore.model;

public enum ProductCategory {
	
	
}
