package com.capstore.model;

public enum InventoryType {
	
	MERCHANT,THIRDPARTY

}