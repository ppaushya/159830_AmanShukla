package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IOrderDao;
import com.capstore.model.Order;
import com.capstore.model.Product;

@Service("orderService")
public class OrderService implements IOrderService {

	@Autowired
	private IOrderDao orderDao;
	@Autowired
	private IProductService productService;
	
	@Override
	public List<Order> displayCart() {
		
		return orderDao.findAll();
	}

	@Override
	public boolean placeOrder(Order order) {
		int productId=order.getProductId();
		List<Product> products=productService.getProduct(productId);
		int orderQty=order.getQuantity();
		int availableQty=products.getQuantity();
		if(orderQty<=availableQty)
		{
			orderDao.save(order);
			products.setQuantity(availableQty-orderQty);
			productService.updateProduct(products);
			return true;
		}
		return false;
	}
	

}
