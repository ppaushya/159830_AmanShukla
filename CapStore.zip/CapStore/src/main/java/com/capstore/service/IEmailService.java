package com.capstore.service;

public interface IEmailService {

}
