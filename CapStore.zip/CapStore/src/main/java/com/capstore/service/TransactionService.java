package com.capstore.service;

public class TransactionService implements ITransactionService{

}
