package com.capstore.service;

import java.util.List;

import com.capstore.model.Product;

public interface IProductService {

	public List<Product> getProduct(List<Product> productId);
	public List<Product> updateProduct(List<Product> products);
}
