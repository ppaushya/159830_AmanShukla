package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IProductDao;
import com.capstore.model.Product;

@Service("productService")
public class ProductService implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	@Override
	public List<Product> getProduct(List<Product> productId) {
		Product product=productDao.findAll(productId);
		return product;
	}

	@Override
	public List<Product> updateProduct(List<Product> products) {
		return productDao.saveAll(products);
	}

	
}
