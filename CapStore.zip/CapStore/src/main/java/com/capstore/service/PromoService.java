package com.capstore.service;

public class PromoService implements IPromoService{

}
