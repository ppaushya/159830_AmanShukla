package com.capstore.service;

public class ShipmentService implements IShipmentService{

}
