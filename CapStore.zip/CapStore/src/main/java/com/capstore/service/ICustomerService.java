package com.capstore.service;

public interface ICustomerService {

}
