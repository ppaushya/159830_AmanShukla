package com.capstore.service;

public class CustomerService implements ICustomerService{

}
