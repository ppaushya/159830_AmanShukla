package com.capstore.service;

public class InvoiceService implements IInvoiceService{

}
