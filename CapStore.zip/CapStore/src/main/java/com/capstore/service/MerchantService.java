package com.capstore.service;

public class MerchantService implements IMerchantService{

}
