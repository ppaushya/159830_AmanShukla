package com.capstore.service;

public interface IInventoryMerchantService {

}
