package com.capstore.service;

public class LoginService implements ILoginService{

}
