package com.capstore.service;

public class EmailService implements IEmailService{

}
