package search;
import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class StepDef {


@Given("^User details$")
public void user_details() throws Throwable {
    
}

@When("^Merchant is Logged in$")
public void merchant_is_Logged_in() throws Throwable {
    
}

@Then("^List of Inventory accordingly$")
public void list_of_Inventory_accordingly() throws Throwable {
    
}

@When("^Admin is Logged in$")
public void admin_is_Logged_in() throws Throwable {
    
}

@Then("^List of Customers,Merchants and Inventory accordingly$")
public void list_of_Customers_Merchants_and_Inventory_accordingly() throws Throwable {
   
}

@When("^User is Logged in$")
public void user_is_Logged_in() throws Throwable {
   
}

@Then("^List of Products, Brands accordingly$")
public void list_of_Products_Brands_accordingly() throws Throwable {
   
}
}
