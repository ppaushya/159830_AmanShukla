package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ServletGeneric extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletGeneric() {
        
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("Generic Servlet Initialized!");
	}

	public void destroy() {
		System.out.println("Generic Servlet Destroyed!");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
		System.out.println("Generic Servlet Service Method");
		PrintWriter out=res.getWriter();
		out.println("<h1>Hello World Aman!</h1>");		//we can give html tags also
		
	}

}
