package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyFirstServletHTTP extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MyFirstServletHTTP() {    
    }

    public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet Initialized!");
	}

	public void destroy() {
		System.out.println("Servlet Destroyed!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("Servlet Service Method");
		PrintWriter out=response.getWriter();
		out.println("<b>Hello World Aman!</b>");		//we can give html tags also
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
