package org.cap.demo04;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		
		Set<String> set=new HashSet<>();
		set.add("jack");
		set.add("jack");
		set.add("sam");
		set.add("tom");
		set.add("kamal");
		set.add("kamal");
		set.add("kamal");
		set.add(null);
		set.add(null);
		

		System.out.println(set);
	}

}
