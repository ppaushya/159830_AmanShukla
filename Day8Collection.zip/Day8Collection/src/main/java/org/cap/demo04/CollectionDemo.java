package org.cap.demo04;

import java.util.ArrayList;
//import java.util.Collection;
import java.util.List;

public class CollectionDemo {

	public static void main(String[] args) {
		
		//types of list declaration
		//ArrayList lst=new ArrayList<>();
		List<Integer> lst=new ArrayList<>();	//List<Integer> only wrapper object, not primitive datatype
												//new ArrayList<*Integer*>(), not necessary on RHS
		//Collection lst=new ArrayList<>();
		//Iterable lst=new ArrayList<>();
		
		lst.add(3);
		//lst.add("Tom");
		lst.add(3);
		lst.add(null);
		//lst.add(45.89);
		//lst.add(5678667869l);
		//lst.add(new Object());
		
		//insertion order followed
		System.out.println(lst);
		
		//System.out.println(lst.get(3));

	}

}