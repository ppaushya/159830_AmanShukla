package org.cap.demo04;

import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Enumeration;

public class ArryLstAndVectorDemo {

	public static void main(String[] args) {
		
		//ArrayList<String> lst=new ArrayList();
		Vector<String> lst=new Vector<>();
		lst.add("tom");
		lst.add("tom1");
		lst.add("tom2");
		lst.add("tom3");
		lst.add("tom4");
		lst.add(null);
		
		Vector<String> lst1=new Vector();
		Object lst2;
		lst1.add("jerry");
		lst1.add("jerry1");
		lst1.add("jerry2");
		lst1.add("jerry3");
		lst1.add("jerry4");
		lst1.add(null);
		
		
		//enhanced for loop
		for(String str:lst)
		{
			System.out.print(str+",");
		}
		System.out.println();
		
		for(String str:lst1)
		{
			System.out.print(str+",");
		}
		System.out.println();
		
		//lst.add("Aman");
		//lst.add(2, "abc");
		//lst.addAll(lst);
		//lst.addAll(2, lst);
								//lst.addElement(obj);
		/*boolean b=lst.contains("Ram");
		System.out.println(b);*/
		//System.out.println(lst.containsAll(lst1));
		//lst.clear();
		//System.out.println(lst.isEmpty());
		//System.out.println(lst.get(2));
		//lst.toArray();
								//lst.toArray(a);
		//lst2=lst.clone();
		//System.out.println(lst.capacity());
		//lst.ensureCapacity(40);
		//System.out.println(lst.capacity());
		//System.out.println(lst.equals("tom"));	//false
		//System.out.println(lst.equals(lst));	//true
		//System.out.println(lst.indexOf("tom4"));
		//System.out.println(lst.lastIndexOf("tom1"));
								//System.out.println(lst.listIterator(2));
		//lst.removeAll(lst);
								//lst.replaceAll(+);
		//lst.retainAll(lst1);
		//lst2=lst.subList(0, 2);
		//lst.trimToSize();
		//System.out.println(lst);
		//System.out.println(lst2);
	
		/*Iterator<String> iterator=lst.iterator();	//reference calls the head of list
		while(iterator.hasNext())
		{
			String str=iterator.next();
			System.out.print(str+",");
		}
		System.out.println();*/
		
		
		/*ListIterator<String> lstIterator=lst.listIterator();
		int count=0;
		while(lstIterator.hasNext())
		{
			String str=lstIterator.next();
			System.out.print(str+"-->");
			count++;
			if(count==3)
				break;
		}
		System.out.println();
		
		while(lstIterator.hasPrevious())	//before invoking this method,
											//there should be a left link in the list
		{
			String str=lstIterator.previous();
			System.out.print(str+"-->");
		}
		System.out.println();*/
		
		
		/*Enumeration<String> enumeration=lst.elements();
		
		while(enumeration.hasMoreElements())
		{
			String str=enumeration.nextElement();
			System.out.println(str+"->");
		}
		System.out.println();*/
	
	}

}