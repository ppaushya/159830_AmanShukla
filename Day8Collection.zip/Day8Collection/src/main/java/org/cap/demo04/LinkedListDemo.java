package org.cap.demo04;

import java.util.LinkedList;
import java.util.Iterator;

public class LinkedListDemo {

	public static void main(String[] args) {
		
		LinkedList<String> lst=new LinkedList();
		lst.add("My");
		lst.add("Name");
		lst.add("Is");
		lst.add("Aman");
		lst.add("Shukla");
		lst.add("SWATI");
		lst.add("MY");
		lst.add("My");
		lst.add("Aman");
		System.out.println(lst);
		
		//System.out.println(lst.size());
		//lst.addFirst("Mr.");
		//lst.addLast("Shukla");
		
		//System.out.println(lst.getLast());
		//lst.removeLast();							//removes last
		//String s1=lst.remove();								//removes first
		//System.out.println(s1);
		//System.out.println(lst);
		//String s=lst.removeFirst();						//removes first
		//System.out.println(s);
		//System.out.println(lst);
		//lst.remove(2);							//removes from the specified index
		//lst.remove("Is");
		//lst.removeFirstOccurrence("Aman");
		//lst.removeLastOccurrence("My");
		System.out.println(lst);
		/*Iterator<String> iterator=lst.iterator();	//reference calls the head of list
		while(iterator.hasNext())					//print the list
		{
			String str=iterator.next();
			System.out.print(str+",");
		}
		System.out.println();*/
		//System.out.println(lst);

	}

}
