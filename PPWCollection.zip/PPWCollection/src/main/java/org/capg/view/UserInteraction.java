package org.capg.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.util.Utility;

public class UserInteraction {

	Scanner sc = new Scanner(System.in);
	ICustomerService customerservice = new CustomerServiceImpl();

	public Transaction doingTransaction(Customer customer) {
		System.out.println("Choose your option:");
		System.out.println("1.Deposit");
		System.out.println("2.Withdrawal");
		System.out.println("3.Funds Transfer");
		int transactionType = sc.nextInt();
		Account account = new Account();
		Transaction transaction = new Transaction();
		int accountNo = 0;
		double amount = 0;

		switch (transactionType) {
		case 1:
			System.out.println("Choose Account to Deposit:");
			printAccounts(customer.getAccounts());
			accountNo = sc.nextInt();
			account = customerservice.ifaccountFound(customer, accountNo);
			if (account == null) {
				System.out.println("Account Number Does Exist for particular Customer ID!!");
				break;
			}
			transaction.setTransactionType("Deposit");
			System.out.println("Enter the amount to be Deposited?");
			amount = sc.nextDouble();
			customerservice.getCurrentBalance(account, accountNo);
			transaction.setToAccount(account);
			transaction.setFromAccount(null);
			System.out.println("Amount Deposited Successfully!!");
			break;

		case 2:
			System.out.println("Choose Account to Withdrawal");
			printAccounts(customer.getAccounts());
			accountNo = sc.nextInt();
			account = customerservice.ifaccountFound(customer, accountNo);
			if (account == null) {
				System.out.println("Account number does not exist for this particular customer ID!!");
				break;
			}
			transaction.setTransactionType("Withdrawal");
			System.out.println("Enter Amount to be Debited:");
			amount = sc.nextDouble();
			if (amount < customerservice.getCurrentBalance(account, accountNo)) {
				transaction.setToAccount(null);
				transaction.setFromAccount(account);
				System.out.println("Amout withdrawn Successfully!");
			}
			else
				System.out.println("Withdraw Error!! Balance Insufficient");
			break;

		case 3:
			System.out.println("Choose account to deposit funds:");
			printAccounts(customer.getAccounts());
			int toAccountNumber = sc.nextInt();
			account = customerservice.ifaccountFound(customer, toAccountNumber);
			if (account == null) {
				System.out.println("Account does not exist for customer id- " + customer.getCustomerID());
				break;
			}
			transaction.setToAccount(account);
			
			
			System.out.println("Choose account to withdraw funds:");
			printAccounts(customer.getAccounts());
			int fromAccountNumber = sc.nextInt();
			account = customerservice.ifaccountFound(customer, fromAccountNumber);
			if (account == null) {
				System.out.println("Account does not exist for customer id- " + customer.getCustomerID());
				break;
			}
			transaction.setFromAccount(account);
			
			
			transaction.setTransactionType("Fund Transfer");

			System.out.println("Enter amount to transfer");
			amount = sc.nextDouble();
			break;

		default:
			System.out.println("Invalid choice!");
			return null;
		}
		System.out.println("Enter description of transaction");
		String description = sc.next();
		transaction.setDescription(description);
		transaction.setAmount(amount);
		transaction.setTransactionID(Utility.generateNumber());
		transaction.setTransationDate(LocalDate.now());
		return transaction;
	}

	public void printSummary(List<Transaction> transactions) {
		System.out.println(
				"TransactionId|TransactionDate|ToAccount\t\t|FromAccount\t\t|amount|TransactionType|Description");
		System.out.println(
				"------------------------------------------------------------------------------------------------------------------------");
		for (Transaction transaction : transactions) {
			System.out.println(transaction.getTransactionID() + "\t" + transaction.getTransationDate() + "\t"
					+ transaction.getToAccount() + "\t" + transaction.getFromAccount() + "\t" + transaction.getAmount()
					+ "\t" + transaction.getTransactionType() + "\t" + transaction.getDescription());
		}
	}

	public Customer getCustomerDetails() {

		Customer customer = new Customer();
		customer.setCustomerID(Utility.generateNumber());
		customer.setFirstName(Utility.promptFirstName());
		customer.setLastName(Utility.promptLastName());
		customer.setEmailID(Utility.promptemailID());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateofBirth(Utility.promptDOB());
		customer.setAddress(getAddressDetails());

		return customer;
	}

	public Account getAccountDetails() {

		Account account = new Account();
		account.setAccountNumber(Utility.generateAccountNumber());
		Utility.printAccountType();
		System.out.println("Choose Account Type[1,2,3,4]:");
		int accountTypeNo = sc.nextInt();
		account.setAccountType(Utility.assignAccountType(accountTypeNo));
		account.setOpeningDate(Utility.promptopeningDate());
		account.setOpeningBalance(Utility.promptopeningBalance());
		account.setDescription(Utility.promptDescription());
		return account;
	}

	public Address getAddressDetails() {

		Address address = new Address();
		address.setAddressLine1(Utility.promptaddress1());
		address.setAddressLine2(Utility.promptaddress2());
		address.setCity(Utility.promptcity());
		address.setState(Utility.promptstate());
		address.setPincode(Utility.promptpincode());
		return address;

	}

	public static void printError(String message) {
		System.out.println(message);
	}

	public static void printCustomers(List<Customer> customers) {
		System.out.println("CustomerID\tCustomerName\t\tEmailID\t\t\tMobileNo. ");
		System.out.println(
				"------------------------------------------------------------------------------------------------------");
		for (Customer customer : customers) {
			System.out.println(customer.getCustomerID() + "\t\t" + customer.getFirstName() + " "
					+ customer.getLastName() + "\t\t" + customer.getEmailID() + "\t\t" + customer.getMobileNo());
		}

	}

	public static void printcustomerAccounts(List<Customer> customers) {
		System.out.println("CustomerID\tCustomerName\t\tEmailID\t\t\tMobileNo. ");
		System.out.println(
				"------------------------------------------------------------------------------------------------------");
		for (Customer customer : customers) {
			System.out.println(customer.getCustomerID() + "\t\t" + customer.getFirstName() + " "
					+ customer.getLastName() + "\t\t" + customer.getEmailID() + "\t\t" + customer.getMobileNo() + "\t\t"
					+ customer.getAccounts());
		}

	}

	public void printAccounts(Set<Account> accounts) {
		System.out.println("AccountNo\tAccount Type\tAccount OpeningBalance\t Account OpeningDate\tDescription... ");
		System.out.println(
				"------------------------------------------------------------------------------------------------------");
		for (Account account : accounts) {
			System.out.println(account.getAccountNumber() + "\t\t" + account.getAccountType() + "\t\t"
					+ account.getOpeningBalance() + "\t\t" + account.getOpeningDate() + "\t\t"
					+ account.getDescription());
		}
	}

}
