package org.capg.model;

import java.time.LocalDate;

public class Transaction {
	
	private long transactionID;
	private LocalDate transationDate;
	private Account fromAccount;
	private Account toAccount;
	private double amount;
	private String description;
	private String transactionType;

	public Transaction() {

	}

	public Transaction(long transactionID, LocalDate transationDate, Account fromAccount, Account toAccount,
			double amount, String description, String transactionType) {
		super();
		this.transactionID = transactionID;
		this.transationDate = transationDate;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
		this.description = description;
		this.transactionType = transactionType;
	}

	public long getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}

	public LocalDate getTransationDate() {
		return transationDate;
	}

	public void setTransationDate(LocalDate transationDate) {
		this.transationDate = transationDate;
	}

	public Account getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}

	public Account getToAccount() {
		return toAccount;
	}

	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionID=" + transactionID + ", transationDate=" + transationDate + ", fromAccount="
				+ fromAccount + ", toAccount=" + toAccount + ", amount=" + amount + ", description=" + description
				+ ", transactionType=" + transactionType + "]";
	}

}
