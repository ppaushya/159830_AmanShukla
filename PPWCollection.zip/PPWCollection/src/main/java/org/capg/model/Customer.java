package org.capg.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Customer {

	private int customerID;
	private String firstName;
	private String lastName;
	private String emailID;
	private String mobileNo;
	private LocalDate dateofBirth;
	private Address address;
	private Set<Account> accounts = new HashSet<>();

	public Customer() {

	}

	public Customer(int customerID, String firstName, String lastName, String emailID, String mobileNo,
			LocalDate dateofBirth, Address address) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.mobileNo = mobileNo;
		this.dateofBirth = dateofBirth;
		this.address = address;
	}

	public Customer(int customerID, String firstName, String lastName, String emailID, String mobileNo,
			LocalDate dateofBirth, Address address, Set<Account> accounts) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.mobileNo = mobileNo;
		this.dateofBirth = dateofBirth;
		this.address = address;
		this.accounts = accounts;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public LocalDate getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(LocalDate dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Set<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(Set<Account> account) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailID=" + emailID + ", mobileNo=" + mobileNo + ", dateofBirth=" + dateofBirth + ", address="
				+ address + ", accounts=" + accounts + "]";
	}

}
