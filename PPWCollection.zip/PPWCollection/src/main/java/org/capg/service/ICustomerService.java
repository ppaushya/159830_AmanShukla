package org.capg.service;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public interface ICustomerService {

	public List<Customer> getAllCustomer();

	public void CreateCustomers(Customer customer);

	public Customer ifFound(int customerID);

	public void addAccount(Customer customer, Account account);

	public Account ifaccountFound(Customer customer, int accountNo);

	public void addTransaction(Transaction transaction);

	public double getCurrentBalance(Account account, int accountNo);

	public List<Transaction> getAllTransaction();
}
