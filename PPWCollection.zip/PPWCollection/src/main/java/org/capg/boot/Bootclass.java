package org.capg.boot;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;

public class Bootclass {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		ICustomerService customerservice = new CustomerServiceImpl();
		UserInteraction userinteraction = new UserInteraction();

		int choice;
		String option;
		do {
			System.out.println("1.Create Customer");
			System.out.println("2.List Customers");
			System.out.println("3.Create New Account ");
			System.out.println("4.Print Customer Details with Account Information ");
			System.out.println("5.Do Transactions");
			System.out.println("6.Transaction Summary");
			System.out.println("Enter your Choice:");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				int count = customerservice.getAllCustomer().size();
				Customer customer = userinteraction.getCustomerDetails();
				customerservice.CreateCustomers(customer);
				if (count == customerservice.getAllCustomer().size()) {
					UserInteraction.printError("Customer Creation Error! Please do it Again!");
				} else
					UserInteraction.printError("Customer Created");
				break;
			case 2:
				List<Customer> customers = customerservice.getAllCustomer();
				UserInteraction.printCustomers(customers);
				break;
			case 3:
				System.out.println("Enter the CustomerID for whom you want to create Account: ");
				customers = customerservice.getAllCustomer();
				userinteraction.printCustomers(customers);
				int customerID = sc.nextInt();
				customer = customerservice.ifFound(customerID);
				if (customer == null) {
					System.out.println("CustomerID not Found!!");
					break;
				}
				System.out.println("Enter Account details:");
				Account account = userinteraction.getAccountDetails();
				System.out.println(account);
				customerservice.addAccount(customer, account);
				break;
			case 4:
				customers = customerservice.getAllCustomer();
				userinteraction.printcustomerAccounts(customers);
				break;
			case 5:
				System.out.println("Enter CustomerID for Transaction: ");
				System.out.println("------------------------------------------------------------");
				customers = customerservice.getAllCustomer();
				userinteraction.printCustomers(customers);
				int customerID1 = sc.nextInt();
				customer = customerservice.ifFound(customerID1);
				if (customer == null) {
					System.out.println("CustomerID not Found!!");
					break;
				}
				Transaction transaction = userinteraction.doingTransaction(customer);
				customerservice.addTransaction(transaction);
				System.out.println("Choose Account number to show Balance");
				userinteraction.printAccounts(customer.getAccounts());
				int accountnumber = sc.nextInt();
				account = customerservice.ifaccountFound(customer, accountnumber);
				if (account == null) {
					System.out.println("Account does not exist!");
					break;
				}
				System.out.println("Current balance=" + customerservice.getCurrentBalance(account, accountnumber));
				break;
			case 6:
				List<Transaction> transactions = customerservice.getAllTransaction();
				userinteraction.printSummary(transactions);
				break;
			default:
				System.out.println("Sorry! Invalid Choice!");
				System.exit(0);
			}
			System.out.println("Do you wish to continue?[y|n]");
			option = sc.next();
		} while (option.charAt(0) == 'y' || option.charAt(0) == 'Y');
	}
}