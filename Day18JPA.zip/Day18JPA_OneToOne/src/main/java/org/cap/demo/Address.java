package org.cap.demo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	private int addressId;
	private String addressLine;
	// @OneToOne Unidirectional
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "address",fetch=FetchType.EAGER) // Bidirectional
	@JoinColumn(name = "custId_fk")
	private Customer customer;

	public Address() {
	}

	public Address(int addressId, String addressLine, Customer customer) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.customer = customer;
	}

	public Address(int addressId, String addressLine) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLine=" + addressLine + "]";
	}
}