package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.demo.Address;
import org.cap.demo.Customer;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();

		transaction.begin();
		Customer customer = new Customer(1001, "Aman");
		Address address = new Address(127191, "Kanpur");
		address.setCustomer(customer);
		
		entityManager.persist(address);
		entityManager.persist(customer);

		transaction.commit();
	}

}
