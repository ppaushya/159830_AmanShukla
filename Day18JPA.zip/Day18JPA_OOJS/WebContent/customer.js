function Customer(custId,custName,regFee,address){
	this.custId=custId;
	this.custName=custName;
	this.regFee=regFee;
	this.address=address;
	
	this.printDetails=function(){
		console.log(custId+'-'+custName+'-'+regFee+'-'+address)
	}
}

var customer=new Customer(1001,'Aman',1000.0,'Kanpur')

customer.printDetails()