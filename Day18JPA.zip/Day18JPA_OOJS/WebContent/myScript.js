var emp={
	empid:101,
	name:'Aman',
	salary:56000
}

var myfun = function() {
	
	for(key in emp){
		console.log(key+'-'+emp[key]);
	}
	console.log("Hello!!");
	console.log(emp.empid);
	console.log(emp.name);
	console.log(emp.salary);
}

myfun()

