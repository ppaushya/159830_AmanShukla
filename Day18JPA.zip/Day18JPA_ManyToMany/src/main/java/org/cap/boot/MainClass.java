package org.cap.boot;

public class MainClass {

	public static void main(String[] args) {
		
		

	}

}
