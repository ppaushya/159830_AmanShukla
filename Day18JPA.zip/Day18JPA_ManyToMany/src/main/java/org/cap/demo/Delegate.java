package org.cap.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Delegate {

	@Id
	private int delegateId;
	private String delegateName;

	public Delegate() {
	}

	public Delegate(int delegateId, String delegateName) {
		super();
		this.delegateId = delegateId;
		this.delegateName = delegateName;
	}

	public int getDelegateId() {
		return delegateId;
	}

	public void setDelegateId(int delegateId) {
		this.delegateId = delegateId;
	}

	public String getDelegateName() {
		return delegateName;
	}

	public void setDelegateName(String delegateName) {
		this.delegateName = delegateName;
	}

	@Override
	public String toString() {
		return "Delegate [delegateId=" + delegateId + ", delegateName=" + delegateName + "]";
	}
}