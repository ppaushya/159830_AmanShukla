package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.demo.Company;
import org.cap.demo.Employee;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();

		transaction.begin();
		Company capg = new Company();
		capg.setCompanyId(101);
		capg.setCompanyName("Capgemini");

		Company tcs = new Company();
		tcs.setCompanyId(102);
		tcs.setCompanyName("TCS");

		Employee tom = new Employee(1001, "tom", tcs);
		Employee jerry = new Employee(1034, "jerry", capg);
		Employee aman = new Employee(11, "aman", tcs);
		Employee amar = new Employee(1671, "amar", capg);
		Employee naman = new Employee(101, "naman", capg);
		Employee rahul = new Employee(1901, "rahul", tcs);

		entityManager.persist(tom);
		entityManager.persist(jerry);
		entityManager.persist(aman);
		entityManager.persist(amar);
		entityManager.persist(naman);
		entityManager.persist(rahul);
		entityManager.persist(tcs);
		entityManager.persist(capg);

		transaction.commit();
		entityManager.close();

	}

}
