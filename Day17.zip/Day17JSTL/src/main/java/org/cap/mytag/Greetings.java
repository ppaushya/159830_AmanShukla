package org.cap.mytag;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Greetings extends SimpleTagSupport {

	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out = getJspContext().getOut();
		StringWriter sw = new StringWriter();
		getJspBody().invoke(sw);

		out.println("<h3>Hello! " + sw + "</h3>");
	}

}
