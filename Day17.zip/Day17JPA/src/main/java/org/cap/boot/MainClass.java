package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();

		transaction.begin();

		Employee employee = new Employee(101, "Aman", "Shukla", 60000);
		Employee employee1 = new Employee(102, "Amar", "Singh", 50000);

		entityManager.persist(employee);
		entityManager.persist(employee1);

		transaction.commit();
	}

}
