package org.cap.demo;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer num1=100;
		Integer num2=2;
		Integer ans=null;
		try {
			ans=num1+num2;
			//System.out.println("Answer: "+ans); 
			
			String num="8s";
			int result=ans/Integer.parseInt(num);
			System.out.println("result: "+result);
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}
		catch(ArithmeticException|NullPointerException e){
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		System.out.println("Answer: "+ans);
	}

}