package org.cap.demo;

public class CheckException {

	public static void main(String[] args) {
		
		int num1=100;
	//	int num2=0;
		String num2="10s";
		
		int result=0;
		
		try
		{
			result=num1/Integer.parseInt(num2);
		}
		
		/*catch(ArithmeticException|NumberFormatException e)
		{
			//System.out.println(e.getMessage());
			e.printStackTrace();
		}*/
		
		finally
		{
			System.out.println("Finally block statement");	
		}
			
		/*catch(NumberFormatException e)
		}
		{
			System.out.println(e.getMessage());
		}*/
		System.out.println("result: "+ result);
	}
}