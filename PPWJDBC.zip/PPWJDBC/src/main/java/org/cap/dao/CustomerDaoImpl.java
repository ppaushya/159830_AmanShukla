package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public class CustomerDaoImpl implements ICustomerDao {

	private static List<Customer> customers = dummyDb();

	private Connection getConnection() {

		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		return null;
	}

	private static List<Customer> dummyDb() {
		List<Customer> customers = new ArrayList<>();

		Address address = new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123, "Jack", "Thomson", LocalDate.of(1991, 01, 23), "jack@gmail.com", "8890912345",
				address, new HashSet<Account>()));

		Address address1 = new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090, "Tom", "Jerry", LocalDate.of(1987, 12, 23), "tom@gmail.com", "9090912345",
				address1, new HashSet<Account>()));

		return customers;
	}

	@Override
	public Customer createCustomer(Customer customer) {

		String query = "INSERT INTO customer (customerId,firstName ,lastName,dateOfBirth,emailId,mobile) VALUES(?,?,?,?,?,?)";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, customer.getCustomerId());
			statement.setString(2, customer.getFirstName());
			statement.setString(3, customer.getLastName());
			statement.setDate(4, java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(5, customer.getEmailId());
			statement.setString(6, customer.getMobile());

			int count = statement.executeUpdate();
			if (count > 0) {
				System.out.println("Customer info inserted");
				query = "select * from customer";
				statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery();
				Customer customer1 = new Customer();
				while (resultSet.next()) {
					customer1.setCustomerId(resultSet.getInt(1));
					customer1.setFirstName(resultSet.getString(2));
					customer1.setLastName(resultSet.getString(3));
					customer1.setDateOfBirth(resultSet.getDate(4).toLocalDate());
					customer1.setEmailId(resultSet.getString(5));
					customer1.setMobile(resultSet.getString(6));
				}
				return customer1;
			} else {
				System.out.println("Error occured.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Address createAddress(Customer customer, Address address) {

		String query = "INSERT INTO address(addressId ,addressLine1,addressLine2,city ,state,pincode ,customerId) VALUES"
				+ "(?,?,?,?,?,?,?)";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, address.getAddressId());
			statement.setString(2, address.getAddressLine1());
			statement.setString(3, address.getAddressLine2());
			statement.setString(4, address.getCity());
			statement.setString(5, address.getState());
			statement.setString(6, address.getPincode());
			statement.setInt(7, customer.getCustomerId());

			int count = statement.executeUpdate();
			if (count > 0) {
				System.out.println("Address info inserted");
				query = "select * from address";
				statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery();
				Address address1 = new Address();
				while (resultSet.next()) {
					address1.setAddressId(resultSet.getInt(1));
					address1.setAddressLine1(resultSet.getString(2));
					address1.setAddressLine2(resultSet.getString(3));
					address1.setCity(resultSet.getString(4));
					address1.setState(resultSet.getString(5));
					address1.setPincode(resultSet.getString(6));
					address1.setCustomerId(resultSet.getInt(7));
				}
				return address1;
			} else {
				System.out.println("Error occured.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomers() {

		List<Customer> customers = new ArrayList<>();
		Customer customer = new Customer();
		String query = "select * from customer";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
				customer.setEmailId(resultSet.getString(5));
				customer.setMobile(resultSet.getString(6));
				customers.add(customer);
			}

			return customers;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Address> getAllAddress() {

		Set<Address> addresses = new HashSet<>();
		Address address = new Address();
		String query = "select * from address";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				address.setAddressId(resultSet.getInt(1));
				address.setAddressLine1(resultSet.getString(2));
				address.setAddressLine2(resultSet.getString(3));
				address.setCity(resultSet.getString(4));
				address.setState(resultSet.getString(5));
				address.setPincode(resultSet.getString(6));
				address.setCustomerId(resultSet.getInt(7));
				addresses.add(address);
			}

			return addresses;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Customer isCustomerFound(int customerId) {
		for (Customer customer : getAllCustomers()) {
			if (customer.getCustomerId() == customerId)
				return customer;
		}
		return null;

	}

	@Override
	public Account isAccountFound(Customer customer, int accountNumber) {
		for (Account account : customer.getAccounts()) {
			if (account.getAccountNumber() == accountNumber)
				return account;
		}
		return null;
	}

	public void AddAccount(Customer customer, Account account) {

		String query = "INSERT INTO account (accountNumber ,accountType  ,openingDate ,openingBalance ,"
				+ "description ,customerId ) VALUES(?,?,?,?,?,?)";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, account.getAccountNumber());
			statement.setDate(3, java.sql.Date.valueOf(account.getOpeningDate()));
			statement.setDouble(4, account.getOpeningBalance());
			statement.setString(5, account.getDescription());
			statement.setInt(6, customer.getCustomerId());

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static List<Transaction> transactions = new ArrayList<>();

	@Override
	public void addTransaction(Transaction transaction) {

		String query = "INSERT INTO acc_transaction (transactionId  ,transactionDate ,fromAccount  ,toAccount  ,"
				+ "amount  ,description ,transactionType  ) VALUES(?,?,?,?,?,?,?)";
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);

			statement.setInt(1, transaction.getTransactionId());
			statement.setDate(2, java.sql.Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(3, transaction.getFromAccount().getAccountNumber());
			statement.setInt(4, transaction.getToAccount().getAccountNumber());
			statement.setDouble(5, transaction.getAmount());
			statement.setInt(6, transaction.getCustomerId());

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Transaction> getAllTransactions() {

		List<Transaction> transactions = new ArrayList<>();
		Transaction transaction = new Transaction();

		String query = "select * from transaction";

		try (Connection connection = getConnection()) {

			PreparedStatement statement = connection.prepareStatement(query);

			statement = connection.prepareStatement(query);

			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {

				transaction.setTransactionId(resultSet.getInt(1));
				transaction.setTransactionDate(resultSet.getDate(2).toLocalDate());

				Account account1 = new Account();

				transaction.setFromAccount(account1);

				Account account2 = new Account();

				transaction.setToAccount(account2);

				transaction.setAmount(resultSet.getDouble(5));
				transaction.setDescription(resultSet.getString(6));
				transaction.setCustomerId(resultSet.getInt(7));

				transactions.add(transaction);
			}

			return transactions;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public double getCurrentBalance(Account account, int accountNumber) {
		double currentBalance = account.getOpeningBalance();
		for (Transaction transaction : getAllTransactions()) {
			if (transaction.getToAccount().getAccountNumber() != 0) {
				if (transaction.getToAccount().getAccountNumber() == accountNumber) {
					if (transaction.getTransactionType().equals("Deposit")) {
						currentBalance += transaction.getAmount();
					} else if (transaction.getTransactionType().equals("Fund Transfer")) {
						currentBalance += transaction.getAmount();
					}
				}
			} else if (transaction.getFromAccount().getAccountNumber() != 0) {
				if (transaction.getFromAccount().getAccountNumber() == accountNumber) {
					if (transaction.getTransactionType().equals("Withdrawal")) {
						currentBalance -= transaction.getAmount();
					} else if (transaction.getTransactionType().equals("Fund Transfer")) {
						currentBalance -= transaction.getAmount();
					}
				}
			}
		}
		return currentBalance;
	}
}