package org.cap.dao;

import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface ICustomerDao {

	public Customer createCustomer(Customer customer);

	public Customer isCustomerFound(int customerId);

	public Account isAccountFound(Customer customer, int accountNumber);

	public void AddAccount(Customer customer, Account account);

	public void addTransaction(Transaction transaction);

	public List<Transaction> getAllTransactions();

	public double getCurrentBalance(Account account, int accountNumber);

	public Address createAddress(Customer customer, Address address);

	public List<Customer> getAllCustomers();

	public Set<Address> getAllAddress();
}
