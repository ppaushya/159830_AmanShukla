package org.cap.demo;

import java.io.File;

public class FileDemo {

	public static void main(String[] args) {

		File file = new File("D:\\Users\\ashukl10\\Desktop\\Asdf\\zxcv.txt");

		if (file.isFile()) {
			if (file.exists()) {
				System.out.println("Readable:" + file.canRead());
				System.out.println("Writeable:" + file.canWrite());
				System.out.println("Executeable:" + file.canExecute());
				System.out.println("Path:" + file.getAbsolutePath());

			} else {
				System.out.println("No File");
			}
		} else if (file.isDirectory()) {
			String[] names = file.list();
			for (String name : names)
				System.out.println(name);
		} else {
			System.out.println("No Directory");
		}

	}
}
