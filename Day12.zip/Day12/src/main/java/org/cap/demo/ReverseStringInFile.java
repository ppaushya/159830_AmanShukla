package org.cap.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReverseStringInFile {
	// utility method to print a char
	/*static void print(char value) {
		System.out.print(value);
	}*/
	static String s="";
	public static void main(String[] args) {
		readFile();
	}

	static void readFile() {
		try {
			// create a FileReader Object by providing File name in the constructor
			FileReader reader = new FileReader("D:\\Users\\ashukl10\\Desktop\\Asdf\\zxcv.txt");
			int c; // this will contain the character value as int
			
			while ((c = reader.read()) != -1) {
				s+=(char)c;
			}
			System.out.println(s);
			for(int j=s.length()-1;j>=0;j--)
				System.out.print(s.charAt(j));
			// close the reader after reading is completed
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}