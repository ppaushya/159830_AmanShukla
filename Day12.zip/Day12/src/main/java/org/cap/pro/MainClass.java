package org.cap.pro;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.time.LocalDate;

public class MainClass {

	public void input(Product pro) {

		OutputStream ops = null;
		ObjectOutputStream objOps = null;
		try {
			ops = new FileOutputStream("D:\\Users\\ashukl10\\Desktop\\Asdf\\Product.txt");
			objOps = new ObjectOutputStream(ops);
			objOps.writeObject(pro);
			objOps.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (objOps != null)
					objOps.close();
			} catch (Exception ex) {

			}
		}

	}

	public void output() {

		InputStream fileIs = null;
		ObjectInputStream objIs = null;
		try {
			fileIs = new FileInputStream("D:\\Users\\ashukl10\\Desktop\\Asdf\\Product.txt");
			objIs = new ObjectInputStream(fileIs);
			Product pro = (Product) objIs.readObject();
			System.out.println(pro);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (objIs != null)
					objIs.close();
			} catch (Exception ex) {

			}
		}

	}

	public static void main(String a[]) {
		MainClass obj = new MainClass();
		Product p1 = new Product(101, "Amul", 500, 50.0, LocalDate.now());
		Product p2 = new Product(102, "Samsung", 1000, 50000.0, LocalDate.of(2018, 03, 13));
		Product p3 = new Product(103, "LG", 1500, 5000.0, LocalDate.of(2006, 03, 03));
		Product p4 = new Product(104, "Cadbury", 2500, 5.0, LocalDate.of(2020, 10, 23));
		Product p5 = new Product(105, "Nokia", 3500, 7000.0, LocalDate.of(2016, 02, 19));
		obj.input(p1);
		obj.output();
		obj.input(p2);
		obj.output();
		obj.input(p3);
		obj.output();
		obj.input(p4);
		obj.output();
		obj.input(p5);
		obj.output();
	}
}