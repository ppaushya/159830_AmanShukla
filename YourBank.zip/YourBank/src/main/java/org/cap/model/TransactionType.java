package org.cap.model;

public enum TransactionType {
	
	CREDIT,DEBIT;

}
