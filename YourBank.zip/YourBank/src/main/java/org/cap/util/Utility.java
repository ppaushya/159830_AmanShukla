package org.cap.util;

public class Utility {

	public static int generateNumber() {
		return (int)(Math.random()*10000/10);
	}
	
	public static boolean isValidateFName(String fname) {
		return fname.matches("[a-zA-Z]{3,}");
	}
	
	public static boolean isValidateLName(String lname) {
		return lname.matches("[a-zA-Z]{3,}");
	}
	
	public static boolean isValidateMail(String email) {
		return email.matches("^(.+)@(.+)$");
	}
	
	public static boolean isValidatePhn(String mobile) {
		return mobile.matches("\\d{10}");
	}
	
	public static boolean isValidateDOB(String dateOfBirth) {
		return dateOfBirth.matches("[0,1,2,3]\\d{1}-[0,1]\\d{1}-(18|19|20)\\d{2}");
	}
	
	public static boolean isValidPincode(String pincode) {
		return pincode.matches("\\d{6}");
	}
	
}