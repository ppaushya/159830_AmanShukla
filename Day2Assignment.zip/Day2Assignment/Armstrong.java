package org.cap.demo;

public class Armstrong {
	
	public void func(int n)
	{
		int sum=0;
		int n1=n;
		while(n!=0)
		{
			int rem=n%10;
			sum+=(rem*rem*rem);
			n/=10;
		}
		if(sum==n1)
			System.out.println(n1);
	}
	public static void main(String[] args)
	{
		Armstrong obj=new Armstrong();
		
		for(int i=1;i<1000;i++)
		{
			obj.func(i);
		}
	}

}
