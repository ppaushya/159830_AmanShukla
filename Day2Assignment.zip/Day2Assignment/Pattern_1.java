package org.cap.demo;

import java.util.Scanner;

public class Pattern_1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number");
		int num = sc.nextInt();

		int i = 0;
		int no = 1;
		int no1 = 2;
		while (no < num) {
			for (i = 0; i < 3;) {
				if (no % 2 != 0) {
					System.out.print(no + " ");
					i++;
				}

				no++;
				if (no >= num)
					break;
			}
			for (int j = 0; j < 3;) {
				if (no1 % 2 == 0) {
					System.out.print(no1 + " ");
					j++;
				}
				no1++;
				if (no1 >= num)
					break;
			}

		}
		sc.close();
	}
}
