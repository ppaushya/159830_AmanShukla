package org.cap.demo;

import java.util.Scanner;

public class SumOfDigit {

	public static void main(String[] args) {

		int num, sum = 0;

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number");
		num = sc.nextInt();

		while (num != 0)
		{
			int rem = num % 10;
			sum += rem;
			num /= 10;
		}
		
		System.out.println("Sum is:" + sum);
		sc.close();
	}

}
