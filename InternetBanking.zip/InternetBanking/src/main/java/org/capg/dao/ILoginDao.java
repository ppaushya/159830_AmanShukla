package org.capg.dao;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginDao {

	public Customer isValidLogin(LoginBean loginBean);

	public boolean createCustomer(Customer customer);

	public Account createAccount(Account account);
}
