package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MainPageServlet")
public class MainPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();

		out.println("<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>MainPage</title>\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"./styles/mainPage.css\">\r\n" + 
				"</head>\r\n" + 
				"<body style=\"background-color: skyblue\">\r\n" + 
				"	<div class=\"mainCnt\">\r\n" + 
				"		<h2 align=\"center\">MainPage</h2>\r\n" + 
				"	</div>\r\n" + 
				"	<div class=\"greet\">\r\n" + 
				"		<h3 align=\"left\">Hello,</h3>\r\n" + 
				"	</div>\r\n" + 
				"	<div class=\"btn-group mainCnt1\">\r\n" + 
				"		<a href=\"view/createAccount.html\" target=\"mainfrm\"><button>Create Account</button></a>\r\n" + 
				"		<a href=\"view/transaction.html\" target=\"mainfrm\"><button>Transaction</button></a>\r\n" + 
				"		<a href=\"view/fundTransfer.html\" target=\"mainfrm\"><button>FundTransfer</button></a>\r\n" + 
				"		<a href=\"view/transactionSummary.html\" target=\"mainfrm\"><button>TransactionSummary</button></a>\r\n" + 
				"		<a href=\"LogoutServlet\"><button>Logout</button></a>\r\n" + 
				"	</div>\r\n" + 
				"	<div id=\"ctrCnt\">\r\n" + 
				"		<iframe name=\"mainfrm\" width=\"1000\" height=\"350\"\r\n" + 
				"			src=\"view/titlePage.html\"></iframe>\r\n" + 
				"	</div>\r\n" + 
				"	<div id=\"footer\">\r\n" + 
				"		<div style=\"float: left; padding-left: 10px;\">InternetBanking</div>\r\n" + 
				"		<div style=\"float: left; margin-left: 750px;\">Banking 2018</div>\r\n" + 
				"	</div>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}
}