package org.cap.demo;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram8 {
	int i, j;
	char a1[],a2[];
	
	public void Anagram(String s1, String s2) {
		a1= new char[s1.length()];
		a2= new char[s2.length()];

		for (i = 0; i < s1.length(); i++) {
			a1[i] = Character.toLowerCase(s1.charAt(i));
		}

		for (j = 0; j < s2.length(); j++) {
			a2[j] = Character.toLowerCase(s2.charAt(j));
		}

		for (int k = 0; k < a1.length; k++) {
			for (int l = k + 1; l < a1.length; l++) {
				if (a1[k] > a1[l]) {
					char temp = a1[k];
					a1[k] = a1[l];
					a1[l] = temp;
				}
			}
		}

		for (int k = 0; k < a2.length; k++) {
			for (int l = k + 1; l < a2.length; l++) {
				if (a2[k] > a2[l]) {
					char temp = a2[k];
					a2[k] = a2[l];
					a2[l] = temp;
				}
			}
		}

		for(int i=0;i<a1.length;i++)
		{
			System.out.print(a1[i]);
		}
		
		System.out.println();
		
		for(int j=0;j<a2.length;j++)
		{
			System.out.print(a2[j]);
		}
		
		System.out.println();
		
		if (Arrays.equals(a1, a2)==true)
			System.out.println("Anagrams");
		else
			System.out.println("Not Anagrams");
	}

	public static void main(String[] args) {
		Anagram8 obj = new Anagram8();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the strings");
		String s1 = sc.nextLine();
		String s2 = sc.nextLine();

		obj.Anagram(s1, s2);
		sc.close();
	}

}
