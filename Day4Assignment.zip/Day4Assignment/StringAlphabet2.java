/*Have the function AlphabetSoup(str) take the str string parameter being passed
 and return the string with the letters in alphabetical order (i.e. hello becomes ehllo).
 Assume numbers and punctuation symbols will not be included in the string.*/

package org.cap.demo;

import java.util.Scanner;

public class StringAlphabet2
{
	String str="",str1="";
	char arr[];
	
	public String AlphabetSoup(String str)
	{
		arr=new char[str.length()];
		for(int i=0;i<str.length();i++)
		{
			arr[i]=str.charAt(i);
		}
		
		for (int i = 0; i < arr.length; i++)
		{
			for (int j = i + 1; j < arr.length; j++)
			{
				if (arr[i] > arr[j])
				{
					char temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
		for(int i=0;i<str.length();i++)
		{
			str1+=arr[i];
		}
		
		return str1;
	}

	public static void main(String[] args)
	{
		StringAlphabet2 obj=new StringAlphabet2();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string");
		String str=sc.nextLine();
	
		System.out.println(obj.AlphabetSoup(str));
		sc.close();
	}
}