package org.cap.demo;

//Have the function LetterChanges(String str) take the str parameter being passed
//and modify it using the following algorithm. Replace every letter in the string
//with the letter following it in the alphabet (ie. c becomes d, z becomes a).
//Then capitalize every vowel in this new string (a, e, i, o, u) and finally return this modified string.

import java.util.Scanner;		

public class ABCD4
{
	String str1="",str2="";
	int q;
	char r;
	
	public String LetterChanges(String str)
	{
		for(int i=0;i<str.length();i++)
		{
			char p=str.charAt(i);
			if(p=='z'||p=='Z')
			{
				q=(int)p-25;
				r=(char)q;
				str1+=r;
			}
			else
			{
				q=(int)p+1;
				r=(char)q;
				str1+=r;
			}
		}
		
		for(int i=0;i<str1.length();i++)
		{
			char s=str1.charAt(i);
			if(s=='a'||s=='e'||s=='i'||s=='o'||s=='u')
			{
				int t=(int)s-32;
				char u=(char)t;
				str2+=u;
			}
			else
				str2+=s;
		}
		return str2;
	}
	
	public static void main(String[] args)
	{
		ABCD4 obj=new ABCD4();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string");
		String str=sc.nextLine();
		
		System.out.println(obj.LetterChanges(str));
		sc.close();

	}

}
