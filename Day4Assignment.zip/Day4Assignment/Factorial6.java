/*Have the function FirstFactorial(int num) take the num parameter being passed
 and return the factorial of it (e.g.if num = 4, return (4 * 3 * 2 * 1)).
 For the test cases, the range will be between 1 and 18
 and the input will always be an integer.*/

package org.cap.demo;

import java.util.Scanner;

public class Factorial6
{

	public int FirstFactorial(int num)
	{
		int p;
		if(num==1)
			return 1;
		
		p = FirstFactorial(num-1)* num;
		return p;
	}
	
	public static void main(String[] args)
	{
		Factorial6 obj=new Factorial6();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num=sc.nextInt();
	
		System.out.println(obj.FirstFactorial(num));
		sc.close();
	}
}
