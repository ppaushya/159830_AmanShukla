package org.cap.demo;

/*Have the function LetterCapitalize(String str) take the str parameter being passed
 * and capitalize the first letter of each word.
* Words will be separated by only one space.*/

import java.util.Scanner;

public class TitleCase3
{
	char p,r;
	int q;
	
	public String LetterCapitalize(String str)
	{
		String str1=" "+str;
		String str2="";
		for(int i=0;i<str1.length();i++)
		{
			if(str1.charAt(i)==' ')
			{
				p=str1.charAt(i+1);
				//System.out.println(p);
				q=(int)p-32;
				//System.out.println(q);
				r=(char)q;
				//System.out.println(r);
				str2+=r;
				i++;
			}
			else
			{
				str2+=str1.charAt(i);
			}
		}
		return str2;
	}
	public static void main(String[] args)
	{
		TitleCase3 obj=new TitleCase3();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string");
		String str=sc.nextLine();
		
		System.out.println(obj.LetterCapitalize(str));
		sc.close();
	}
}
