//Prime fraction of a number. Like 6 = {2,3}, 24 = {2,2,2,3}.

package org.cap.demo;

import java.util.Scanner;

public class Prime1
{	
	public void Prime(int num)
	{
		 // Print the number of 2s that divide n 
        while (num%2==0) 
        { 
            System.out.print(2 + " "); 
            num /= 2; 
        } 
  
        // n must be odd at this point.  So we can 
        // skip one element (Note i = i +2) 
        for (int i = 3; i <= Math.sqrt(num); i+= 2) 
        { 
            // While i divides n, print i and divide n 
            while (num %i == 0) 
            { 
                System.out.print(i + " "); 
                num /= i; 
            } 
        } 
  
        // This condition is to handle the case whien 
        // n is a prime number greater than 2 
        if (num > 2) 
            System.out.print(num);
	}
	
	public static void main(String[] args)
	{
		Prime1 obj=new Prime1();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num=sc.nextInt();
		
		obj.Prime(num);
		sc.close();

	}

}
