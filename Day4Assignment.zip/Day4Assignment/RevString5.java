/*Have the function ReverseOrder(String str) take the str parameter being passed
 * and return the string in reversed order.
 * *For example: if the input string is "Hello World and Coders"
 * then your program should return the string sredoC dna dlroW olleH.*/

package org.cap.demo;

import java.util.Scanner;

public class RevString5
{
	char arr[];
	String s="";
	
	public String ReverseOrder(String str)
	{
		arr=new char[str.length()];
		for(int i=0;i<str.length();i++)
		{
			arr[i]=str.charAt(i);
		}
		
		for(int i=0;i<str.length();i++)
		{
			System.out.print(arr[i]);
		}
		
		System.out.println();
		
		for(int i=arr.length-1;i>=0;i--)
		{
			s+=arr[i];
		}
		return s;
	}
	
	public static void main(String[] args)
	{
		RevString5 obj=new RevString5();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string");
		String str=sc.nextLine();
	
		System.out.println(obj.ReverseOrder(str));
		sc.close();
	}

}
