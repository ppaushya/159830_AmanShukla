package org.cap.sample;

public class RegularClassDemo {
	
	int num;
	String name;
	
	class innerClass{
		
		String address;
		
		public void show() {
			
			System.out.println(num);
			System.out.println(name);
			System.out.println(address);
			
		}
	}
}
