package org.cap.demo;

public class IntegerWrap {

	public static void main(String[] args) {
		
		Integer num=100;
		Integer myNum=new Integer(100);
		Integer value=100;
		Integer myValue=new Integer(100);
		
		System.out.println(num.equals(myNum));
		System.out.println(num==myNum); 
		
		System.out.println(num.equals(value));
		System.out.println(num==value); 
		
		System.out.println(myNum.equals(num));
		System.out.println(myValue==myNum); 
		
	}

}
