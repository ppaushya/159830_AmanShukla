package org.cap.demo;

import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;

public class Demo {

	public static void main(String[] args) {
		/*LocalDate now=LocalDate.now();
		
		`LocalDate nextSunday=now.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
		
		//TemporalAdjusters.
		LocalDate previousSunday=now.with(TemporalAdjusters.previous(DayOfWeek.SUNDAY));*/
		
		Instant instant=Instant.now();
		System.out.println(instant);
		
		/*Date date=Date.from(instant);
		Instant instant1=date.toInstant();
		System.out.println(instant1);*/
		
		TimeStamp time=TimeStamp.from(instant);
		Instant instant1=time.toInstant();
		System.out.println(instant1);
			
		Date date=Date.from(localDate);
		LocalDate localDate
	}

}
