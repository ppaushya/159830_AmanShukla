package org.cap.demo;

public class StringBuilderDemo {

	public static void main(String[] args) {
		
		StringBuilder buffer=new StringBuilder(50);
		buffer.append("Tom");
		
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
		
		buffer.ensureCapacity(100);
		
		/*buffer.insert(0,"Jerry");*/
		buffer.replace(0, 3, "Jerry");
		/*buffer.append("Jerry bnbk dgk nbvdf  f viomo");*/
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
	}

}
