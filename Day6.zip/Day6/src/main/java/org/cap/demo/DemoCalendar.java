package org.cap.demo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DemoCalendar
{

	public static void main(String[] args) {

		Calendar calendar=new GregorianCalendar();
		System.out.println(calendar);
	
		System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
		System.out.println(calendar.get(Calendar.DAY_OF_WEEK));
		System.out.println(calendar.get(Calendar.DATE));
		
		Calendar today=Calendar.getInstance();
		System.out.println(today);
		
		System.out.println(today.getTime());
		today.add(Calendar.YEAR, 3);
		System.out.println(today);
		
		today.set(Calendar.YEAR, 2010);
		System.out.println(today.get(Calendar.YEAR));
		
		System.out.println(today.getMaximum(calendar.YEAR));
		System.out.println(today.getMinimum(calendar.YEAR));
		
		System.out.println(today.getMaximum(calendar.MONTH));
		System.out.println(today.getMinimum(calendar.DAY_OF_WEEK_IN_MONTH));
		
	}

}
