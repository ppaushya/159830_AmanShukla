package org.cap.demo;

import java.util.Date;

public class DateDemo
{

	public static void main(String[] args)
	{
		Date today=new Date();
		System.out.println(today);
		
		Date dob=new Date(1991-1900,01,23);
		System.out.println(dob);
		
		System.out.println(dob.getTime());
		System.out.println(today.getTime());
		
		Date myDate=new Date();
		System.out.println(myDate);
		
		System.out.println(today.before(dob));
		System.out.println(getDate());
		
	}

}
