package org.cap.demo;

public class StringBufferDemo {

	public static void main(String[] args) {
		
		StringBuffer buffer=new StringBuffer("Tom");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
		
		/*buffer.insert(0,"Jerry");*/
		buffer.replace(0, 3, "Jerry");
		/*buffer.append("Jerry bnbk dgk nbvdf  f viomo");*/
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
	}

}
