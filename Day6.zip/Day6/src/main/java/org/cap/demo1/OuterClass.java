package org.cap.demo1;

public class OuterClass {
	
	String name="Jerry";
	
	public void details() {
		
		int count=100;
		
		class Temp{
			
			int num=45;
			String name="Jack";
			
			public void print() {
				
				OuterClass obj=new OuterClass();
				System.out.println("Num:"+num);
				System.out.println("Name:"+name);
				System.out.println("Name:"+obj.name);
			}
		}
	}
	public static void main(String[] args) {
		

	}

}
