package org.demo.cap;

public abstract class AbstractClass {
	
	abstract void print();

}
 