package conference;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webdriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\amanadityashukla\\chromedriver\\chromedriver.exe");
		webdriver = new ChromeDriver();
	}

	@Given("^Conference Registration Page$")
	public void conference_Registration_Page() throws Throwable {
		webdriver.get("file:///D:/amanadityashukla/Conferencebooking/ConferenceRegistartion.html");
	}

	@When("^title does not match$")
	public void title_does_not_match() throws Throwable {
		String title = webdriver.getTitle();
		assertNotEquals("Conference Registration", title);
	}

	@When("^heading does not match$")
	public void heading_does_not_match() throws Throwable {
		WebElement heading = webdriver.findElement(By.tagName("h4"));
		assertNotEquals("Step 1: Personal Details ", heading);
	}

	@Then("^test should stop execute$")
	public void test_should_stop_execute() throws Throwable {
		webdriver.quit();
	}

	@When("^enter the details$")
	public void enter_the_details() throws Throwable {
		WebElement element = webdriver.findElement(By.name("txtFN"));
		element.sendKeys("Aman");
		
		WebElement element1 = webdriver.findElement(By.name("txtLN"));
		element1.sendKeys("Shukla");
		
		WebElement element2 = webdriver.findElement(By.name("Email"));
		element.sendKeys("aman@gmail.com");
		
		WebElement element3 = webdriver.findElement(By.name("Phone"));
		element.sendKeys("9648958781");
		
		Select 
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
	   
	}


	
}
