package org.cap.demo;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo2 {

	public static void main(String[] args) {
		
		//HashSet<Integer> set=new HashSet<>();
		//LinkedHashSet<Integer> set=new LinkedHashSet<>();
		TreeSet<Integer> set=new TreeSet<>();
		set.add(4);
		set.add(4);
		set.add(5);
		//set.add(null);
		set.add(645645);
		//set.add(null);
		set.add(58975349);
		//set.add(null);
		
		
		
		System.out.println(set);

	}

}
