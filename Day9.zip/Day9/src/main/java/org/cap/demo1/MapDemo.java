package org.cap.demo1;

import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
	
		//Map<Integer,String> maps=new HashMap<>();
		Map<Integer,String> maps=new Hashtable<>();
		maps.put(1, "One");
		maps.put(2, "Two");
		maps.put(1110, "Eleven");
		//maps.put(null, "Eleven");
		maps.put(11, "Eleven");
		//maps.put(null, "Three");
		
		//System.out.println(maps);
		
		/*Set<Integer> set=maps.keySet();
		Iterator<Integer> iterator=set.iterator();
		
		while(iterator.hasNext())
		{
			int key=iterator.next();
			System.out.println(key+"-->"+maps.get(key));
		}*/
		
		//maps.put(23, null);
		//maps.put(34, null);
		
		Collection<String> values=maps.values();
		for(String str:values)
		{
			System.out.println(str);
		}
		
		/*Enumeration<String> enumerations=maps.elements();
		while(enumerations.hasMoreElements())
		{
			System.out.println(enumerations.nextElement());
		}*/
	}

}