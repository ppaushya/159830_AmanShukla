package org.cap.pojo;

//import java.util.HashSet;
import java.util.Iterator;
//import java.util.LinkedHashSet;
import java.util.TreeSet;

public class MainClass {

	public static void main(String[] args) {
		
		//HashSet<Employee> employees=new HashSet<>();
		//LinkedHashSet<Employee> employees=new LinkedHashSet<>();
		TreeSet<Employee> employees=new TreeSet<>();	//class cast exception,if not Comparable
		employees.add(new Employee(1,"aom",30000));
		employees.add(new Employee(2,"fman",40000));
		employees.add(new Employee(3,"dditya",5000));
		employees.add(new Employee(4,"farun",60000));
		employees.add(new Employee(5,"eaheer",70000));
		
		Iterator<Employee> iterator=employees.iterator();
	
		while(iterator.hasNext())
		{
			Employee employee=iterator.next();
			System.out.println(employee+",");
		}
	}
}