package org.cap.pojo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class TestClass {

	public static void main(String[] args) {
		
		ArrayList<Employee> employees=new ArrayList<>();
		employees.add(new Employee(1,"tom",30000));
		employees.add(new Employee(2,"aman",40000));
		employees.add(new Employee(3,"aditya",5000));
		employees.add(new Employee(4,"tarun",60000));
		employees.add(new Employee(5,"zaheer",70000));
		
		Collections.sort(employees);
		
		Iterator<Employee> iterator=employees.iterator();
		
		while(iterator.hasNext())
		{
			Employee employee=iterator.next();
			System.out.println(employee+",");
		}

	}

}
