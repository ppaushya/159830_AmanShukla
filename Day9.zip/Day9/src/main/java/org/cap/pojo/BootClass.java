package org.cap.pojo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class BootClass {

	public static void main(String[] args) {
		
		Map<Customer,Address> maps=new TreeMap<>();
		maps.put(new Customer(101,"Aman"), new Address("ABC","XYZ","Kanpur","UP"));
		maps.put(new Customer(102,"Amar"), new Address("ABC1","XYZ1","Paanpur","UK"));
		maps.put(new Customer(103,"Amar1"), new Address("ABC2","XYZ2","Ranpur","UP"));
		maps.put(new Customer(104,"Aman3"), new Address("ABC3","XYZ3","Zabad","UPA"));
		maps.put(new Customer(105,"Aman9"), new Address("ABC8","XYZ6","Lucknow","UP2"));
		
		System.out.println(maps);
		
		maps.keySet();
		Set<Customer> set=maps.keySet();
		Iterator<Customer> iterator=set.iterator();
		while(iterator.hasNext())
		{
			Customer key=iterator.next();
			System.out.println(key+"-->"+maps.get(key));
		}
		
		Collection<Address> values=maps.values();
		for(Address str:values) {
			System.out.println(str);
		}
		
	}
}