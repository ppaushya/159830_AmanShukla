package org.cap.demo;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {	//needed for war packaging
		return application.sources(SpringBootDemoApplication.class);						//web appl., not standalone
	}

}
