package org.cap.thread;

class MainClass4 {
	public static void main(String args[]) {
		final Customer c = new Customer();
		Thread t = new Thread() {

			@Override
			public void run() {
				c.withdraw(15000);
			}
		};
		t.start();

		Thread t1 = new Thread() {

			@Override
			public void run() {
				c.deposit(15000);
			}
		};
		t1.start();
		

		/*
		 * t1.setPriority(Thread.MAX_PRIORITY); System.out.println(t1.getPriority());
		 */
	}
}