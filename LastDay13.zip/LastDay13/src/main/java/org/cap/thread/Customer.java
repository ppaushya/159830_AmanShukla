package org.cap.thread;

public class Customer {

	int amount = 1000;

	public Customer() {

	}

	public synchronized void withdraw(int amount) {
		System.out.println("Going to withdraw....");

		if (this.amount < amount)
			System.out.println("Insufficient balance....Waiting for deposit");
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.amount -= amount;
		System.out.println("Withdraw Done!!");
	}

	public synchronized void deposit(int amount) {
		System.out.println("Going to Deposit....");
		this.amount += amount;
		System.out.println("Deposit Completed!!");
		notify();
	}
}
