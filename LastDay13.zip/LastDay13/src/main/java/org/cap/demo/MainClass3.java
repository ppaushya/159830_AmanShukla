package org.cap.demo;

public class MainClass3 {

	public static void main(String[] args) {

		ProductTable runnable = new ProductTable();
		Thread t1 = new Thread(runnable, "13"); // pass ref in threadClass arg
		Thread t2 = new Thread(runnable, "15"); // pass ref in threadClass arg alongwith String(threadName)
		Thread t3 = new Thread(runnable, "21"); // pass ref in threadClass arg

		t1.start(); // new thread instance created
		// t1.run(); //no new thread created,current thread executed i.e., "main" or
		// other
		try {
			t1.join(1000); // first this thread executed
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		t3.start();
	}

}
