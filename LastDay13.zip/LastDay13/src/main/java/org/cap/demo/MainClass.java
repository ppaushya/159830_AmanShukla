package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		MyThread t1=new MyThread();
		MyThread t2=new MyThread("Capg Thread");
		MyThread t3=new MyThread();
		
		t1.start();
		t2.start();
		t3.start();

	}

}
