package org.cap.demo;

public class ProductTable implements Runnable {

	@Override
	public void run() {

		for (int i = 1; i <= 10; i++) {
			/*
			 * try { Thread.sleep(1000); } catch (InterruptedException e) { //
			 * checkedException e.printStackTrace(); }
			 */
			System.out.println(Thread.currentThread().getName() + "-->" + Thread.currentThread().getName() + "*" + i
					+ "=" + i * (Integer.parseInt(Thread.currentThread().getName())));

		}

	}
}
