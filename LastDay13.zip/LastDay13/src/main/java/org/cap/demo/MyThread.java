package org.cap.demo;

public class MyThread extends Thread{

	public MyThread(String threadName) {								//parameterized constructor
		super(threadName);
	}

	public MyThread() {													//default constructor
		
	}

	@Override
	public void run() {
		System.out.println(getName()+"-->"+"Thread Started......");		// order of threads decided
																		//by thread-scheduler in JVM
	}
}
