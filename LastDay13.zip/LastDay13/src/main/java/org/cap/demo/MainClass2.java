package org.cap.demo;

public class MainClass2 {

	public static void main(String[] args) {

		ThreadDemo runnable = new ThreadDemo(); // instance
		Thread t1 = new Thread(runnable); // pass ref in threadClass arg
		Thread t2 = new Thread(runnable, "Capg Thread"); // pass ref in threadClass arg alongwith String(threadName)
		Thread t3 = new Thread(runnable); // pass ref in threadClass arg

		t1.start();
		try {
			t1.join(1000); // first this thread executed
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t3.start();

		// shuffled order
	}

}