package createDiffAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private Account account;
	private Customer customer;
	private IAccountService accountService;

	@Mock
	private IAccountDao accountDao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService = new AccountServiceImpl(accountDao);
	}

	@Given("^Customer Details$")
	public void customer_Details() throws Throwable {
		Address address = new Address("34 North Street", "Pune");
		this.customer = new Customer("Kamal", "Singh", address);
	}

	@When("^For valid customer with minimum opening balance (\\d+)$")
	public void for_valid_customer_with_minimum_opening_balance(int balance) throws Throwable {
		assertNotNull(this.customer);

		Account account = new Account();
		account.setCustomer(this.customer);
		account.setOpeningBalance(balance);

		Mockito.when(accountDao.createAccount(account)).thenReturn(true);

		// Actual Logic
		this.account = accountService.createAccount(this.customer, balance);

		// Mockito Verification
		Mockito.verify(accountDao).createAccount(account);
	}

	@Then("^create new savings account$")
	public void create_new_savings_account() throws Throwable {
		assertEquals("savings", "savings", this.account.getAccountType());
	}

	@Then("^create new current account$")
	public void create_new_current_account() throws Throwable {
		assertEquals("current", "current", this.account.getAccountType());
	}

	@Then("^create new rd account$")
	public void create_new_rd_account() throws Throwable {
		assertEquals("rd", "rd", this.account.getAccountType());
	}

	@Then("^create new fd account$")
	public void create_new_fd_account() throws Throwable {
		assertEquals("fd", "fd", this.account.getAccountType());
	}
}