package org.cap.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Customer;
import org.cap.model.Register;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RegisterController {
	
	private Register register;
	@Autowired
	private IRegisterService registerService;
	private boolean flag;
	
	@RequestMapping("/register")
	public String showRegistrationPage(ModelMap map) {
		List<Register> registers= registerService.getAllRegistration();
		String butLabel="Update";
		
		if(!flag) {
			butLabel="Register";
			map.addAttribute("register", new Register());
		}
		else
			map.addAttribute("register",register);
		
		map.addAttribute("qualifications", getQualifications());
		map.addAttribute("butLabel",butLabel);
		map.addAttribute("registers", registers);
		map.addAttribute("flag", flag);
		//flag=false;
		return "register";
	}
	

	//@RequestMapping(value="/registerForm",method=RequestMethod.POST)
	@PostMapping("/registerForm")
	public String registerDetails(
			@Valid @ModelAttribute("register")Register register,
				BindingResult result,HttpSession session) {
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		register.setCustomer(customer);
		
		if(result.hasErrors())
			return "register";
		 
		if(!flag)
			registerService.insertRegistration(register);
		else {
			registerService.updateRegistration(register);
			flag=false;
		}
		System.out.println(register);
		return "redirect:register";
	}
	
	
	
	@RequestMapping("/delete/{registrationId}")
	public String deleteRegistration(@PathVariable("registrationId") Integer registrationId) {
		
		registerService.deleteRegistration(registrationId);
		
		return "redirect:/register";
	}
	
	
	@RequestMapping("/edit/{registrationId}")
	public String editRegistration(@PathVariable("registrationId") Integer registrationId) {
		
		flag=true;
		register=registerService.findRegistration(registrationId);
		System.out.println(register);
		return "redirect:/register";
	}
	
	
	
	
	
	
	
	
	private List<String> getQualifications(){
		List<String> list=new ArrayList<>();
		list.add("ME");
		list.add("BE");
		list.add("MBA");
		list.add("MCA");
		list.add("PHD");
		list.add("BSC");
		list.add("MSC");
		
		return list;
	}
	
	
	
	
	
	
	
	
}
















