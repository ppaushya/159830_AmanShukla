package org.cap.model;


public class LoginPojo {
	

	private int userid;
	
	
	private String userName;
	
	private String userPassword;
	
	public LoginPojo() {
		
	}
	
	public LoginPojo(String userName, String userPassword) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	
	
	public int getUserid() {
		return userid;
	}

	public void setCustomerId(int userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "LoginPojo [userName=" + userName + ", userPassword=" + userPassword + "]";
	}
	
	

}
