package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Customer;
import org.cap.model.LoginPojo;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{
	
	@PersistenceContext
	private EntityManager em;

	@Override
	
	public Customer isValidLogin(LoginPojo loginPojo) {
		
		String sql="from Customer where emailId=:uname and customerPwd=:userpwd";
		Query query= em.createQuery(sql);
		query.setParameter("uname", loginPojo.getUserName());
		query.setParameter("userpwd", loginPojo.getUserPassword());
		
		List<Customer> list= query.getResultList();
		
		if(!list.isEmpty())
			return list.get(0);
		
		return null;
	}

}
