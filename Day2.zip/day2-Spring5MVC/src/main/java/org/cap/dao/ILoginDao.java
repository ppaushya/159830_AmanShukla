package org.cap.dao;

import java.util.List;

import org.cap.model.Customer;
import org.cap.model.LoginPojo;
import org.cap.model.Register;

public interface ILoginDao {

	
	public Customer isValidLogin(LoginPojo loginPojo);
	
	
}
