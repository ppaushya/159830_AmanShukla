package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.LoginPojo;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
//		String sql="from LoginPojo where username=:username and password=:password";
		String sql="from Customer where emailId=:emailId and password=:password";
		Query query= em.createQuery(sql);
		query.setParameter("emailId", loginPojo.getUsername());
		query.setParameter("password", loginPojo.getPassword());
		
		List<LoginPojo> list= query.getResultList();
		
		if(!list.isEmpty())
			return true;
		
		return false;
	}

}
