package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.RegisterPojo;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("registerDao")
@Transactional
public class RegisterDaoImpl implements IRegisterDao{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean registerCustomer(RegisterPojo registerPojo) {
		em.persist(registerPojo);
		return true;
	}

	@Override
	public List<RegisterPojo> getAllRegistration() {
		List<RegisterPojo> registerPojos = em.createQuery("from RegisterPojo").getResultList();
		System.out.println("size "+registerPojos.size());
		return registerPojos;
	}

	@Override
	public void deleteRegistration(int customerId) {
		RegisterPojo registerPojo = em.find(RegisterPojo.class,customerId);
		em.remove(registerPojo);
		
	}

	@Override
	public RegisterPojo findRegistration(int customerId) {
		RegisterPojo registerPojo = em.find(RegisterPojo.class,customerId);
		return registerPojo;
	}

	@Override
	public void updateRegistration(RegisterPojo registerPojo) {
		//RegisterPojo updated = em.find(RegisterPojo.class,registerPojo.getCustomerId());
		
		em.merge(registerPojo);
		/*updated.setFirstName(registerPojo.getFirstName());
		updated.setLastName(registerPojo.getLastName());
		updated.setAddress(registerPojo.getAddress());
		updated.setCity(registerPojo.getCity());
		updated.setGender(registerPojo.getGender());
		updated.setQualification(registerPojo.getQualification());
		updated.setDateOfBirth(registerPojo.getDateOfBirth());
		updated.setPassword(registerPojo.getPassword());
		updated.setConfirmPassword(registerPojo.getConfirmPassword());
		updated.setRegistrationFees(registerPojo.getRegistrationFees());
		updated.setEmailId(registerPojo.getEmailId());*/
	}

}
