package org.cap.service;

import java.util.List;

import org.cap.model.RegisterPojo;

public interface IRegisterService {

	public boolean registerCustomer(RegisterPojo registerPojo);
	public List<RegisterPojo> getAllRegistration();
	public void deleteRegistration(int customerId);
	public void updateRegistration(RegisterPojo registerPojo);
	public RegisterPojo findRegistration(int customerId);
}
