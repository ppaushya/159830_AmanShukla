package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.cap.model.RegisterPojo;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RegisterController {
	
	@Autowired
	private IRegisterService registerService;
	
	private boolean isUpdate = false;
	private RegisterPojo registerPojo;
	
	@RequestMapping("/register")
	public String showRegistrationPage(ModelMap modelmap) {
		List<RegisterPojo> registers = registerService.getAllRegistration();
		String buttonLabel = "Register";
		if(isUpdate) {
			modelmap.addAttribute("register",registerPojo);
			buttonLabel = "Update";
			//modelmap.addAttribute("formAction","updateCustomer/"+registerPojo.getCustomerId());
		}else {
			modelmap.addAttribute("register",new RegisterPojo());
			//modelmap.addAttribute("formAction","register");
		}

		modelmap.addAttribute("flag",isUpdate);
		modelmap.addAttribute("registerList",registers);
		modelmap.addAttribute("qualificationList",getQualifications());
		modelmap.addAttribute("buttonLabel",buttonLabel);
		return "register";
	}
	
	//@RequestMapping(value= "/register",method=RequestMethod.POST)
	@PostMapping("/register")
	public String registerDetails(ModelMap modelmap,@Valid @ModelAttribute("register") RegisterPojo register
			,BindingResult result) {
		System.out.println("POST");
		if(!result.hasErrors()) {
			if(isUpdate) {
				System.out.println("UPDATEEEEEEE");
				registerService.updateRegistration(register);
			}else {
				System.out.println("REGISTERRRRRR");
				boolean s = registerService.registerCustomer(register);
				if(!s) {
					System.out.println("Registration error");
				}
			}
			isUpdate = false;
		}else {
			System.out.println(result.getErrorCount());
		}
		return "redirect:/register";
	}
	
	/*//@RequestMapping(value= "/register",method=RequestMethod.POST)
	@PostMapping("/updateCustomer/{customerId}")
	public String updateDetails(ModelMap modelmap,@PathVariable("customerId")Integer customerId,
			@Valid @ModelAttribute("register") RegisterPojo register
			,BindingResult result) {
		if(!result.hasErrors()) {
			register.setCustomerId(customerId);
			registerService.updateRegistration(register);
			return "redirect:/register";
		}else {
			System.out.println(result.getErrorCount());
		}
		return "register";
	}*/
	
	@RequestMapping("/delete/{customerId}")
	public String deleteRegistration(@PathVariable("customerId")Integer customerId) {
		registerService.deleteRegistration(customerId);
		
		return "redirect:/register";
	}
	
	@RequestMapping("/edit/{customerId}")
	public String editRegistration(@PathVariable("customerId")Integer customerId) {
		isUpdate = true;
		registerPojo = registerService.findRegistration(customerId);
		return "redirect:/register";
	}
	
	private List<String> getQualifications() {
		List<String> qualificationList = new ArrayList<String>();
		
		qualificationList.add("BTech");
		qualificationList.add("BE");
		qualificationList.add("MBA");
		qualificationList.add("BSc");
		qualificationList.add("BCom");
		
		return qualificationList;
	}
}
