package org.cap.boot;

import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {

		// ApplicationContext context = new ClassPathXmlApplicationContext("myBeans.xml");
		AbstractApplicationContext context = new FileSystemXmlApplicationContext(
						"D:\\SpringFrameWork\\Day1SpringCore\\target\\classes\\myBeans.xml");

		// one request
		Employee employee = (Employee) context.getBean("emp"); // down-casting
																// getBean method of "BeanFactory" class,
																// returns object of associated class
		// another request
		Employee employee1 = (Employee) context.getBean("emp");

		employee.setEmployeeName("Aman");

		System.out.println(employee);
		System.out.println(employee1);

		// context.close();
		context.registerShutdownHook();
	}
}