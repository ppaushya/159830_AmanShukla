package org.cap.boot;

import org.cap.model.CollectionDemo;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context = 
				new ClassPathXmlApplicationContext("collectionBean.xml");

		CollectionDemo demo = (CollectionDemo) context.getBean("myDemo");

		System.out.println(demo.getNames());
		System.out.println(demo.getAddresses());
		
		context.close();
	}
}
